lidosuites.controller('homectrl', ['$http', '$scope', '$location','$routeParams', function($http, $scope, $location, $routeParams){
	$scope.message = 'Home';
}]);