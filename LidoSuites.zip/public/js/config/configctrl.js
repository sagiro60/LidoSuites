lidosuites.controller('configctrl', ['$http', '$scope', '$location','$routeParams', function($http, $scope, $location, $routeParams){
	$scope.message = 'Configuraciones';
}]);