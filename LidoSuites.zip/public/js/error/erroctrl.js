lidosuites.controller('errorctrl', ['$http', '$scope', '$location','$routeParams', function($http, $scope, $location, $routeParams){
	$scope.message = 'Error 404';
}]);