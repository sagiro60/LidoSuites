'use strict';
var lidosuites = angular.module('lidosuites', ['ngRoute']); 