<?php

require_once '../models/usuario.php';

$usuario = new Usuario();
$usuario->delSession();