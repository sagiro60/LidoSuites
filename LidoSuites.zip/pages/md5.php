<?php 

var_dump(md5("12345"));